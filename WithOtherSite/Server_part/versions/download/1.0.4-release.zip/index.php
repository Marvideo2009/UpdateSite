<?php

include('config.php');

echo get_current_version();
echo "2";